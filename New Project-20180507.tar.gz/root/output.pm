#!/usr/bin/perl
package output;
1;