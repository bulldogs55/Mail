#!/usr/bin/perl
package misc;
1;
