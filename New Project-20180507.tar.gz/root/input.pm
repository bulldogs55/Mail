#!/usr/bin/perl
package input;
1;