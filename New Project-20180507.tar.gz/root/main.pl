#!/usr/bin/perl
require input;
require math;
require localTime;
require input;
require output;
print $localTime::hour;
print "\n";