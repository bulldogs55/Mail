#!/usr/bin/perl
package math;
$hello = 5;
sub sum{
    @numbers = (@_);
    foreach $number(@numbers){
        $sum += $number;
    }
    return $sum;
}

sub average{
    @numbers = (@_);
    $n = scalar(@numbers);
    foreach $number(@numbers){
        $sum += $number;
    }
    $average = $sum/$n;
    return $average;
}
1;